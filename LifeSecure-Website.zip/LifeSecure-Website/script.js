const waPhone = "60149449065";

const screenHome = document.getElementById("screen-home");
const screenForm = document.getElementById("screen-form");
const screenResults = document.getElementById("screen-results");

const goToFormBtn = document.getElementById("goToFormBtn");
const backBtn = document.getElementById("backBtn");
const insuranceForm = document.getElementById("insuranceForm");
const packageList = document.getElementById("packageList");

function showScreen(screenToShow) {
  [screenHome, screenForm, screenResults].forEach((screen) => {
    screen.classList.remove("active");
  });
  screenToShow.classList.add("active");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

goToFormBtn.addEventListener("click", () => {
  const quickAge = document.getElementById("quickAge").value;
  const quickBudget = document.getElementById("quickBudget").value;
  const quickGoal = document.getElementById("quickGoal").value;

  if (quickAge) document.getElementById("age").value = quickAge;
  if (quickBudget) document.getElementById("budget").value = quickBudget;
  if (quickGoal) document.getElementById("goal").value = quickGoal;

  showScreen(screenForm);
});

backBtn.addEventListener("click", () => {
  showScreen(screenForm);
});

function getRecommendedPlan(age, budget, smoker, marital, goal) {
  let recommended = "Standard";

  if (budget <= 120) {
    recommended = "Basic";
  } else if (budget >= 380 || marital === "Married" || goal === "Family Protection") {
    recommended = "Premium";
  } else {
    recommended = "Standard";
  }

  if (smoker === "Yes" && recommended === "Basic") {
    recommended = "Standard";
  }

  if (Number(age) >= 45 && recommended === "Basic") {
    recommended = "Standard";
  }

  return recommended;
}

function buildPackages(age, budget, smoker, marital, goal) {
  const smokerLoad = smoker === "Yes" ? 30 : 0;
  const ageLoad = Number(age) >= 45 ? 40 : Number(age) >= 35 ? 20 : 0;
  const familyLoad = marital === "Married" || goal === "Family Protection" ? 20 : 0;
  const goalLoad =
    goal === "Hibah Takaful" ? 10 :
    goal === "Medical Card" ? 20 : 30;

  const basicPrice = Math.max(120, Number(budget) - 20 + smokerLoad / 2 + ageLoad / 2);
  const standardPrice = Math.max(240, Number(budget) + smokerLoad + ageLoad + goalLoad / 2);
  const premiumPrice = Math.max(380, Number(budget) + 80 + smokerLoad + ageLoad + familyLoad + goalLoad);

  return [
    {
      key: "Basic",
      label: "Basic",
      title: "Basic",
      price: Math.round(basicPrice),
      description: "Essential protection with lower monthly contribution.",
      benefits: [
        "Medical card coverage",
        "Basic life protection",
        "Well support"
      ]
    },
    {
      key: "Standard",
      label: "Standard",
      title: "Standard",
      price: Math.round(standardPrice),
      description: "Balanced protection with moderate monthly contribution.",
      benefits: [
        "Comprehensive medical card",
        "Critical illness cover",
        "Family protection",
        "Investment-linked"
      ]
    },
    {
      key: "Premium",
      label: "Premium",
      title: "Premium",
      price: Math.round(premiumPrice),
      description: "Maximum coverage with highest protection benefits.",
      benefits: [
        "Medical coverage",
        "Life & critical illness",
        "Hibah / wealth",
        "Accident cover"
      ]
    }
  ];
}

function createWhatsAppLink(data, pkg) {
  const message =
    `Hi, I completed the insurance recommendation form.%0A%0A` +
    `Name: ${encodeURIComponent(data.fullName)}%0A` +
    `Age: ${encodeURIComponent(data.age)}%0A` +
    `Gender: ${encodeURIComponent(data.gender)}%0A` +
    `Smoking: ${encodeURIComponent(data.smoker)}%0A` +
    `Marital Status: ${encodeURIComponent(data.marital)}%0A` +
    `Monthly Budget: RM${encodeURIComponent(data.budget)}%0A` +
    `Protection Goal: ${encodeURIComponent(data.goal)}%0A` +
    `Interested Package: ${encodeURIComponent(pkg.title)}%0A` +
    `Estimated Contribution: RM${encodeURIComponent(pkg.price)}/month%0A%0A` +
    `I would like to know more.`;

  return `https://wa.me/${waPhone}?text=${message}`;
}

insuranceForm.addEventListener("submit", function (e) {
  e.preventDefault();

  const data = {
    fullName: document.getElementById("fullName").value.trim(),
    age: document.getElementById("age").value,
    gender: document.getElementById("gender").value,
    smoker: document.getElementById("smoker").value,
    marital: document.getElementById("marital").value,
    budget: document.getElementById("budget").value,
    goal: document.getElementById("goal").value
  };

  const recommendedPlan = getRecommendedPlan(
    data.age,
    Number(data.budget),
    data.smoker,
    data.marital,
    data.goal
  );

  const packages = buildPackages(
    data.age,
    Number(data.budget),
    data.smoker,
    data.marital,
    data.goal
  );

  packageList.innerHTML = "";

  packages.forEach((pkg) => {
    const isRecommended = pkg.key === recommendedPlan;

    const card = document.createElement("div");
    card.className = `package-card ${isRecommended ? "recommended" : ""}`;

    card.innerHTML = `
      ${isRecommended ? `<div class="recommended-badge">Recommended</div>` : ""}
      <div class="plan-label">${pkg.label}</div>
      <div class="plan-price">RM ${pkg.price}<span>/month</span></div>
      <div class="package-desc">${pkg.description}</div>
      <ul class="package-benefits">
        ${pkg.benefits.map((item) => `<li>${item}</li>`).join("")}
      </ul>
      <div class="package-footer">
        <div class="plan-name">${pkg.title}</div>
        <a class="wa-btn" href="${createWhatsAppLink(data, pkg)}" target="_blank">Chat on Whatsapp</a>
      </div>
    `;

    packageList.appendChild(card);
  });

  showScreen(screenResults);
});